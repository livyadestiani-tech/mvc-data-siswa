CREATE DATABASE IF NOT EXISTS db_siswa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_siswa;

CREATE TABLE IF NOT EXISTS siswa (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(30) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    kelas VARCHAR(30) NOT NULL,
    jenis_kelamin ENUM('Laki-laki','Perempuan') NOT NULL DEFAULT 'Laki-laki',
    alamat TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO siswa (nis, nama, kelas, jenis_kelamin, alamat) VALUES
('2026001', 'Alya Putri', 'XII RPL 1', 'Perempuan', 'Bandung'),
('2026002', 'Rizky Pratama', 'XII RPL 1', 'Laki-laki', 'Cimahi'),
('2026003', 'Nadia Safitri', 'XI RPL 2', 'Perempuan', 'Sumedang');
