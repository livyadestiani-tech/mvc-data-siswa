# Aplikasi Data Siswa - PHP MVC CRUD

Aplikasi sederhana untuk mengelola data siswa dengan arsitektur MVC (Model, View, Controller), PHP PDO, dan MySQL.

## Fitur
- **Create**: menambahkan data siswa
- **Read**: menampilkan tabel daftar siswa
- **Update**: mengubah data siswa
- **Delete**: menghapus data siswa dengan konfirmasi
- Query menggunakan prepared statements dan output HTML di-escape untuk mengurangi risiko SQL injection dan XSS.

## Persyaratan
- PHP 8.0 atau lebih baru (ekstensi PDO MySQL aktif)
- MySQL/MariaDB
- XAMPP, Laragon, atau server PHP lokal lainnya

## Cara menjalankan dengan XAMPP
1. Ekstrak folder `mvc-data-siswa` ke `C:/xampp/htdocs/`.
2. Buka phpMyAdmin (`http://localhost/phpmyadmin`).
3. Pilih tab **Import**, lalu impor file `database/db_siswa.sql`. Alternatifnya, jalankan isi SQL tersebut di tab SQL.
4. Jika username/password MySQL berbeda, ubah properti di `config/database.php`.
5. Pastikan Apache dan MySQL berjalan.
6. Buka `http://localhost/mvc-data-siswa/public/`. URL lama `http://localhost/mvc-data-siswa/` tetap bisa digunakan karena diarahkan ke folder `public`.

## Struktur folder
```text
mvc-data-siswa/
├── app/
│   ├── controllers/SiswaController.php
│   ├── models/Siswa.php
│   └── views/
│       ├── layout/header.php
│       ├── layout/footer.php
│       └── siswa/
│           ├── index.php
│           └── form.php
├── config/database.php
├── database/db_siswa.sql
├── public/style.css
├── index.php
└── README.md
```

## Catatan
- Konfigurasi bawaan memakai MySQL `localhost`, database `db_siswa`, username `root`, password kosong (umum pada XAMPP).
- Ini contoh proyek pembelajaran. Untuk deployment publik, tambahkan autentikasi, perlindungan CSRF, validasi yang lebih ketat, dan pengelolaan error produksi.


## Pencarian data siswa
Di halaman daftar siswa, gunakan kotak pencarian untuk mencari berdasarkan NIS, nama, kelas, jenis kelamin, atau alamat. Tekan tombol Cari. Tombol Reset mengembalikan seluruh data. Pencarian memakai parameter query PDO (prepared statement).
