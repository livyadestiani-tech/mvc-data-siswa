</main>
<footer class="footer">Aplikasi CRUD Data Siswa · Struktur Model-View-Controller</footer>
</body>
</html>
