<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title ?? 'Data Siswa') ?></title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar"><div class="container"><span class="brand">SISWA<span>KU</span></span><span class="subtitle">Aplikasi Data Siswa · PHP MVC</span></div></header>
<main class="container">
