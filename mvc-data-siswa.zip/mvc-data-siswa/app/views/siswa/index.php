<?php
$title = 'Data Siswa';

require __DIR__ . '/../layout/header.php';

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$keyword = $keyword ?? '';
$siswa = $siswa ?? [];
?>

<section class="page-heading">
    <div>
        <p class="eyebrow">PENGELOLAAN SEKOLAH</p>
        <h1>Data Siswa</h1>
        <p class="muted">
            Kelola informasi siswa dalam satu tempat.
        </p>
    </div>

    <a class="btn btn-primary" href="index.php?action=create">
        + Tambah Siswa
    </a>
</section>

<?php if (isset($_GET['success'])): ?>
    <div class="alert">
        Data berhasil
        <?= e([
            'tambah' => 'ditambahkan',
            'ubah'   => 'diperbarui',
            'hapus'  => 'dihapus'
        ][$_GET['success']] ?? 'diproses') ?>.
    </div>
<?php endif; ?>

<section class="panel">

    <div class="panel-header">
        <div>
            <h2>Daftar Siswa</h2>

            <p class="muted">
                <?php if ($keyword !== ''): ?>
                    Ditemukan <?= count($siswa) ?> hasil untuk
                    "<?= e($keyword) ?>"
                <?php else: ?>
                    <?= count($siswa) ?> data terdaftar
                <?php endif; ?>
            </p>
        </div>

        <span class="pill">CRUD Aktif</span>
    </div>

    <!-- FORM PENCARIAN -->
    <form
        method="get"
        action="index.php"
        class="search-form"
    >
        <input
            type="search"
            name="q"
            value="<?= e($keyword) ?>"
            placeholder="Cari NIS, nama, kelas, jenis kelamin, atau alamat..."
            aria-label="Cari data siswa"
        >

        

        <?php if ($keyword !== ''): ?>
            <a href="index.php" class="btn btn-light">
                Reset
            </a>
        <?php endif; ?>
    </form>

    <!-- TABEL DATA SISWA -->
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($siswa)): ?>
                    <tr>
                        <td colspan="7" class="empty">
                            <?php if ($keyword !== ''): ?>
                                Data siswa dengan kata kunci
                                "<?= e($keyword) ?>" tidak ditemukan.
                            <?php else: ?>
                                Belum ada data siswa.
                                Klik "Tambah Siswa" untuk memulai.
                            <?php endif; ?>
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($siswa as $i => $row): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>

                            <td>
                                <span class="nis">
                                    <?= e($row['nis']) ?>
                                </span>
                            </td>

                            <td class="name-cell">
                                <?= e($row['nama']) ?>
                            </td>

                            <td>
                                <span class="class-tag">
                                    <?= e($row['kelas']) ?>
                                </span>
                            </td>

                            <td>
                                <?= e($row['jenis_kelamin']) ?>
                            </td>

                            <td>
                                <?= e($row['alamat']) ?>
                            </td>

                            <td>
                                <div class="actions">
                                    <a
                                        class="btn btn-small btn-edit"
                                        href="index.php?action=edit&id=<?= (int) $row['id'] ?>"
                                    >
                                        Edit
                                    </a>

                                    <form
                                        method="post"
                                        action="index.php?action=delete"
                                        onsubmit="return confirm('Yakin ingin menghapus data siswa ini?')"
                                    >
                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $row['id'] ?>"
                                        >

                                        <button
                                            class="btn btn-small btn-delete"
                                            type="submit"
                                        >
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
            </tbody>
        </table>
    </div>

</section>

<?php require __DIR__ . '/../layout/footer.php'; ?>