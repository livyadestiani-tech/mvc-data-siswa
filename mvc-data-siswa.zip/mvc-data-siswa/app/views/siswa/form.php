<?php
$title = $pageTitle;
require __DIR__ . '/../layout/header.php';
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
?>
<section class="page-heading">
  <div><p class="eyebrow">FORMULIR SISWA</p><h1><?= e($pageTitle) ?></h1><p class="muted">Lengkapi informasi di bawah ini.</p></div>
  <a class="btn btn-light" href="index.php">← Kembali</a>
</section>
<section class="panel form-panel">
  <form method="post" action="index.php?action=<?= e($formAction) ?>">
    <div class="form-grid">
      <div class="field"><label for="nis">NIS <span>*</span></label><input id="nis" name="nis" value="<?= e($data['nis']) ?>" required maxlength="30" placeholder="Contoh: 2026001"></div>
      <div class="field"><label for="nama">Nama lengkap <span>*</span></label><input id="nama" name="nama" value="<?= e($data['nama']) ?>" required maxlength="100" placeholder="Nama siswa"></div>
      <div class="field"><label for="kelas">Kelas <span>*</span></label><input id="kelas" name="kelas" value="<?= e($data['kelas']) ?>" required maxlength="30" placeholder="Contoh: XII RPL 1"></div>
      <div class="field"><label for="jenis_kelamin">Jenis kelamin</label><select id="jenis_kelamin" name="jenis_kelamin">
        <option value="Laki-laki" <?= $data['jenis_kelamin']==='Laki-laki'?'selected':'' ?>>Laki-laki</option>
        <option value="Perempuan" <?= $data['jenis_kelamin']==='Perempuan'?'selected':'' ?>>Perempuan</option>
      </select></div>
      <div class="field field-full"><label for="alamat">Alamat</label><textarea id="alamat" name="alamat" rows="3" placeholder="Alamat tempat tinggal"><?= e($data['alamat']) ?></textarea></div>
    </div>
    <p class="hint"><span>*</span> Wajib diisi</p>
    <div class="form-actions"><a class="btn btn-light" href="index.php">Batal</a><button class="btn btn-primary" type="submit">Simpan Data</button></div>
  </form>
</section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
