<?php
require_once __DIR__ . '/../../config/database.php';

class Siswa {
    private PDO $db;

    public function __construct() {
        $this->db = (new Database())->connect();
    }

    public function all(): array {
        return $this->db->query('SELECT * FROM siswa ORDER BY id DESC')->fetchAll();
    }

    // Mencari siswa berdasarkan NIS, nama, kelas, jenis kelamin, atau alamat.
    public function search(string $keyword): array {
        $sql = 'SELECT * FROM siswa
                WHERE nis LIKE :nis
                   OR nama LIKE :nama
                   OR kelas LIKE :kelas
                   OR jenis_kelamin LIKE :jenis_kelamin
                   OR alamat LIKE :alamat
                ORDER BY id DESC';
        $stmt = $this->db->prepare($sql);
        $term = '%' . $keyword . '%';
        $stmt->execute([
            'nis' => $term,
            'nama' => $term,
            'kelas' => $term,
            'jenis_kelamin' => $term,
            'alamat' => $term,
        ]);
        return $stmt->fetchAll();
    }

    public function find(int $id): ?array {
        $stmt = $this->db->prepare('SELECT * FROM siswa WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): bool {
        $stmt = $this->db->prepare(
            'INSERT INTO siswa (nis, nama, kelas, jenis_kelamin, alamat)
             VALUES (:nis, :nama, :kelas, :jenis_kelamin, :alamat)'
        );
        return $stmt->execute($data);
    }

    public function update(int $id, array $data): bool {
        $data['id'] = $id;
        $stmt = $this->db->prepare(
            'UPDATE siswa SET nis=:nis, nama=:nama, kelas=:kelas,
             jenis_kelamin=:jenis_kelamin, alamat=:alamat WHERE id=:id'
        );
        return $stmt->execute($data);
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare('DELETE FROM siswa WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
