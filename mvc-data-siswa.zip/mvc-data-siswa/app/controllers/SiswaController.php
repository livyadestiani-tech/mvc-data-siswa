<?php
require_once __DIR__ . '/../models/Siswa.php';

class SiswaController {
    private Siswa $model;

    public function __construct() {
        $this->model = new Siswa();
    }

    public function index(): void {
        // Ambil kata kunci dari kotak pencarian (GET).
        $keyword = trim($_GET['q'] ?? '');
        $siswa = $keyword !== ''
            ? $this->model->search($keyword)
            : $this->model->all();
        require __DIR__ . '/../views/siswa/index.php';
    }

    public function create(): void {
        $data = ['nis'=>'', 'nama'=>'', 'kelas'=>'', 'jenis_kelamin'=>'Laki-laki', 'alamat'=>''];
        $pageTitle = 'Tambah Data Siswa';
        $formAction = 'store';
        require __DIR__ . '/../views/siswa/form.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
        $data = $this->validateInput();
        $this->model->create($data);
        header('Location: index.php?success=tambah'); exit;
    }

    public function edit(): void {
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        $data = $id ? $this->model->find($id) : null;
        if (!$data) { http_response_code(404); echo 'Data siswa tidak ditemukan.'; return; }
        $pageTitle = 'Edit Data Siswa';
        $formAction = 'update&id=' . $id;
        require __DIR__ . '/../views/siswa/form.php';
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id || !$this->model->find($id)) { header('Location: index.php?error=notfound'); exit; }
        $data = $this->validateInput();
        $this->model->update($id, $data);
        header('Location: index.php?success=ubah'); exit;
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if ($id) $this->model->delete($id);
        header('Location: index.php?success=hapus'); exit;
    }

    private function validateInput(): array {
        $nis = trim($_POST['nis'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $kelas = trim($_POST['kelas'] ?? '');
        $jk = $_POST['jenis_kelamin'] ?? 'Laki-laki';
        $alamat = trim($_POST['alamat'] ?? '');
        if ($nis === '' || $nama === '' || $kelas === '') {
            http_response_code(422);
            exit('NIS, nama, dan kelas wajib diisi. Silakan kembali dan lengkapi formulir.');
        }
        if (!in_array($jk, ['Laki-laki', 'Perempuan'], true)) $jk = 'Laki-laki';
        return ['nis'=>$nis, 'nama'=>$nama, 'kelas'=>$kelas, 'jenis_kelamin'=>$jk, 'alamat'=>$alamat];
    }
}
